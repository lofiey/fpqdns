// load block rules

// domain blocker core

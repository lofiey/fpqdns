// app lifecycle


# fpqDNS v2

This is fpqDNS v2 with admin API (JWT protected) and frontend UI (vanilla JS).
Build and run:
```
go mod tidy
cd cmd/fpqdns
go build -o fpqdns
./fpqdns
```
Admin UI: http://127.0.0.1:8053/ (login: admin / changeme)


package resolver

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net/http"
	"time"

	"github.com/miekg/dns"
	"fpqdns/internal/config"
)

func queryUDP(server string, msg *dns.Msg, timeout time.Duration) (*dns.Msg, error) {
	c := new(dns.Client)
	c.Net = "udp"
	c.Timeout = timeout
	in, _, err := c.Exchange(msg, server)
	return in, err
}

func queryDoH(server string, msg *dns.Msg, timeout time.Duration) (*dns.Msg, error) {
	pkt, err := msg.Pack()
	if err != nil { return nil, err }
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "POST", server, bytes.NewReader(pkt))
	req.Header.Set("Content-Type", "application/dns-message")
	client := &http.Client{Timeout: timeout}
	resp, err := client.Do(req)
	if err != nil { return nil, err }
	defer resp.Body.Close()
	if resp.StatusCode != 200 { return nil, errors.New("upstream doh status != 200") }
	b, err := io.ReadAll(resp.Body)
	if err != nil { return nil, err }
	out := new(dns.Msg)
	if err := out.Unpack(b); err != nil { return nil, err }
	return out, nil
}

func Resolve(msg *dns.Msg, preferChina bool) (*dns.Msg, error) {
	for _, up := range config.Cfg.Upstreams {
		if preferChina && up.Type == "udp" {
			resp, err := queryUDP(up.Addr, msg, 2*time.Second)
			if err == nil { return resp, nil }
		}
		if !preferChina && up.Type == "doh" {
			resp, err := queryDoH(up.Addr, msg, 4*time.Second)
			if err == nil { return resp, nil }
		}
	}
	for _, up := range config.Cfg.Upstreams {
		if up.Type == "udp" {
			resp, err := queryUDP(up.Addr, msg, 2*time.Second)
			if err == nil { return resp, nil }
		} else if up.Type == "doh" {
			resp, err := queryDoH(up.Addr, msg, 4*time.Second)
			if err == nil { return resp, nil }
		}
	}
	return nil, errors.New("no upstream")
}

func InitUpstreams() {
	// config already loaded; nothing to init for now
}

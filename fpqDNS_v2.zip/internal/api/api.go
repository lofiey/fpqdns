
package api

import (
	"encoding/json"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"fpqdns/internal/config"
	"fpqdns/internal/rules"

	"github.com/golang-jwt/jwt/v5"
)

func writeJSON(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}

func StartAdmin() {
	http.HandleFunc("/api/login", handleLogin)
	http.HandleFunc("/api/blocklist", authMiddleware(handleBlocklist))
	http.HandleFunc("/api/blocklist/import", authMiddleware(handleBlocklistImport))
	http.HandleFunc("/api/split", authMiddleware(handleSplit))
	http.HandleFunc("/api/split/import", authMiddleware(handleSplitImport))
	http.HandleFunc("/api/upstreams", authMiddleware(handleUpstreams))
	http.HandleFunc("/api/stats", authMiddleware(handleStats))
	http.HandleFunc("/api/reload", authMiddleware(handleReload))
	go func() {
		log.Println("admin API running on :8080")
		log.Fatal(http.ListenAndServe(":8080", nil))
	}()
}

func handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "method", 405); return
	}
	var cred struct{ Username, Password string }
	_ = json.NewDecoder(r.Body).Decode(&cred)
	// simple static check (in future read users file)
	if cred.Username == "admin" && cred.Password == "changeme" {
		claims := jwt.MapClaims{"username": cred.Username, "exp": time.Now().Add(24 * time.Hour).Unix()}
		token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
		s, err := token.SignedString([]byte(config.Cfg.Admin.JWTSecret))
		if err != nil {
			http.Error(w, "token error", 500); return
		}
		writeJSON(w, map[string]string{"token": s})
		return
	}
	http.Error(w, "unauthorized", 401)
}

// Blocklist handlers
func handleBlocklist(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		// read file and return list
		b, err := io.ReadFile(config.Cfg.Rules.BlockFile)
		if err != nil {
			writeJSON(w, map[string]interface{}{"rules": []string{}})
			return
		}
		lines := []string{}
		for _, l := range strings.Split(string(b), "\n") {
			t := strings.TrimSpace(l)
			if t == "" || strings.HasPrefix(t, "#") {
				continue
			}
			lines = append(lines, t)
		}
		writeJSON(w, map[string]interface{}{"rules": lines})
		return
	case "POST":
		var req struct{ Domain string }
		_ = json.NewDecoder(r.Body).Decode(&req)
		if req.Domain == "" {
			http.Error(w, "empty", 400); return
		}
		if err := rules.AddBlock(req.Domain); err != nil {
			http.Error(w, "write err", 500); return
		}
		writeJSON(w, map[string]string{"status": "ok"})
		return
	case "DELETE":
		var req struct{ Domain string }
		_ = json.NewDecoder(r.Body).Decode(&req)
		if req.Domain == "" { http.Error(w, "empty", 400); return }
		if err := rules.DeleteBlock(req.Domain); err != nil { http.Error(w, "del err", 500); return }
		writeJSON(w, map[string]string{"status": "ok"})
		return
	default:
		http.Error(w, "method", 405); return
	}
}

func handleBlocklistImport(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" { http.Error(w, "method", 405); return }
	var req struct{ Url string }
	_ = json.NewDecoder(r.Body).Decode(&req)
	if req.Url == "" { http.Error(w, "empty", 400); return }
	n, err := rules.ImportFromURL(req.Url, "blocklist.txt")
	if err != nil { http.Error(w, "import err", 500); return }
	writeJSON(w, map[string]interface{}{"imported": n})
}

// Split handlers (suffix list)
func handleSplit(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
		b, err := io.ReadFile(config.Cfg.Rules.SplitFile)
		if err != nil { writeJSON(w, map[string]interface{}{"rules": []string{}}); return }
		lines := []string{}
		for _, l := range strings.Split(string(b), "\n") {
			t := strings.TrimSpace(l)
			if t == "" || strings.HasPrefix(t, "#") { continue }
			lines = append(lines, t)
		}
		writeJSON(w, map[string]interface{}{"rules": lines})
		return
	case "POST":
		var req struct{ Suffix string }
		_ = json.NewDecoder(r.Body).Decode(&req)
		if req.Suffix == "" { http.Error(w, "empty", 400); return }
		if err := rules.AddSplit(req.Suffix); err != nil { http.Error(w, "write err", 500); return }
		writeJSON(w, map[string]string{"status": "ok"}); return
	case "DELETE":
		var req struct{ Suffix string }
		_ = json.NewDecoder(r.Body).Decode(&req)
		if req.Suffix == "" { http.Error(w, "empty", 400); return }
		if err := rules.DeleteSplit(req.Suffix); err != nil { http.Error(w, "del err", 500); return }
		writeJSON(w, map[string]string{"status": "ok"}); return
	default:
		http.Error(w, "method", 405); return
	}
}

func handleSplitImport(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" { http.Error(w, "method", 405); return }
	var req struct{ Url string }
	_ = json.NewDecoder(r.Body).Decode(&req)
	if req.Url == "" { http.Error(w, "empty", 400); return }
	n, err := rules.ImportFromURL(req.Url, "china_suffixes.txt")
	if err != nil { http.Error(w, "import err", 500); return }
	writeJSON(w, map[string]interface{}{"imported": n})
}

// Upstreams simple handlers: read config file for now, and allow append
func handleUpstreams(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case "GET":
\t\twriteJSON(w, map[string]interface{}{\"upstreams\": config.Cfg.Upstreams})
\t\treturn
\tcase \"POST\":
\t\tvar u config.Upstream
\t\t_ = json.NewDecoder(r.Body).Decode(&u)
\t\t// append to config file: naive approach - open and append as YAML not implemented; for now just update in-memory and return ok\n\t\tconfig.Cfg.Upstreams = append(config.Cfg.Upstreams, u)\n\t\twriteJSON(w, map[string]string{\"status\":\"ok\"})\n\t\treturn\n\tcase \"DELETE\":\n\t\tvar req struct{ Name string }\n\t\t_ = json.NewDecoder(r.Body).Decode(&req)\n\t\tif req.Name == \"\" { http.Error(w, \"empty\", 400); return }\n\t\tnew := []config.Upstream{}\n\t\tfor _, up := range config.Cfg.Upstreams { if up.Name != req.Name { new = append(new, up) } }\n\t\tconfig.Cfg.Upstreams = new\n\t\twriteJSON(w, map[string]string{\"status\":\"ok\"}); return\n\tdefault:\n\t\thttp.Error(w, \"method\", 405); return\n\t}\n}\n\nfunc handleStats(w http.ResponseWriter, r *http.Request) {\n\t// minimal stats\n\twriteJSON(w, map[string]interface{}{\"total\":0, \"blocked\":0, \"cacheHit\":0, \"uptime\":\"unknown\"})\n}\n\nfunc handleReload(w http.ResponseWriter, r *http.Request) {\n\t// reload rules\n\trules.LoadAll(\"rules\")\n\twriteJSON(w, map[string]string{\"status\":\"reloaded\"})\n}\n\n// simple JWT auth middleware\nfunc authMiddleware(next http.HandlerFunc) http.HandlerFunc {\n\treturn func(w http.ResponseWriter, r *http.Request) {\n\t\tif r.Method == \"OPTIONS\" { w.WriteHeader(200); return }\n\t\tauth := r.Header.Get(\"Authorization\")\n\t\tif auth == \"\" { http.Error(w, \"unauth\", 401); return }\n\t\tparts := strings.SplitN(auth, \" \", 2)\n\t\tif len(parts) != 2 { http.Error(w, \"unauth\", 401); return }\n\t\ttok := parts[1]\n\t\t_, err := jwt.Parse(tok, func(t *jwt.Token) (interface{}, error) {\n\t\t\treturn []byte(config.Cfg.Admin.JWTSecret), nil\n\t\t})\n\t\tif err != nil { http.Error(w, \"unauth\", 401); return }\n\t\tnext(w, r)\n\t}\n}\n
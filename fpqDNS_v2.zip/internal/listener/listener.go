
package listener

import (
	"io"
	"log"
	"net/http"

	"github.com/miekg/dns"
	"fpqdns/internal/cache"
	"fpqdns/internal/resolver"
	"fpqdns/internal/rules"
)

func dohHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "only POST supported", 405)
		return
	}
	if r.Header.Get("Content-Type") != "application/dns-message" {
		http.Error(w, "content-type must be application/dns-message", 400)
		return
	}
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "read error", 500)
		return
	}
	req := new(dns.Msg)
	if err := req.Unpack(body); err != nil {
		http.Error(w, "invalid dns packet", 400)
		return
	}
	if len(req.Question) == 0 {
		http.Error(w, "no question", 400)
		return
	}
	q := req.Question[0].Name
	if rules.IsBlocked(q) {
		m := new(dns.Msg)
		m.SetRcode(req, dns.RcodeNameError)
		out, _ := m.Pack()
		w.Header().Set("Content-Type", "application/dns-message")
		w.Write(out)
		return
	}
	key := q + "/" + dns.TypeToString[req.Question[0].Qtype]
	if data, ok := cache.Get(key); ok {
		w.Header().Set("Content-Type", "application/dns-message")
		w.Write(data)
		return
	}
	preferChina := rules.IsChinaSuffix(q)
	resp, err := resolver.Resolve(req, preferChina)
	if err != nil {
		log.Println("resolve error:", err)
		http.Error(w, "upstream error", 502)
		return
	}
	out, _ := resp.Pack()
	cache.Set(key, out, 300)
	w.Header().Set("Content-Type", "application/dns-message")
	w.Write(out)
}

func Start() error {
	http.HandleFunc("/dns-query", dohHandler)
	// serve admin static and API handled by internal/api via same server
	http.Handle("/", http.FileServer(http.Dir("web")))
	log.Println("starting server on :8053 (DoH + admin static)")
	return http.ListenAndServe(":8053", nil)
}


package cache

import (
	"sync"
	"time"
)

type Entry struct { Data []byte; Expires time.Time }
var mu sync.RWMutex
var store map[string]Entry

func InitCache() { store = make(map[string]Entry) }

func Get(k string) ([]byte,bool) {
	mu.RLock(); e,ok := store[k]; mu.RUnlock()
	if !ok { return nil,false }
	if time.Now().After(e.Expires) { mu.Lock(); delete(store,k); mu.Unlock(); return nil,false }
	return e.Data, true
}

func Set(k string, b []byte, ttl int) {
	mu.Lock(); store[k] = Entry{Data:b, Expires: time.Now().Add(time.Duration(ttl)*time.Second)}; mu.Unlock()
}

func List() map[string]Entry { mu.RLock(); defer mu.RUnlock(); out := make(map[string]Entry); for k,v := range store { out[k]=v }; return out }

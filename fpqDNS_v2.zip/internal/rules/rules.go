
package rules

import (
	"bufio"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"time"

	"github.com/fsnotify/fsnotify"
)

type Rules struct {
	Block map[string]struct{}
	Split []string
}

var current atomic.Value // *Rules
var rulesDir string

func LoadAll(dir string) {
	rulesDir = dir
	r := &Rules{Block: map[string]struct{}{}, Split: []string{}}
	block := filepath.Join(dir, "blocklist.txt")
	split := filepath.Join(dir, "china_suffixes.txt")
	loadFileToMap(block, r.Block)
	loadFileToSlice(split, &r.Split)
	current.Store(r)
}

func loadFileToMap(path string, m map[string]struct{}) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		parts := strings.Fields(line)
		d := parts[len(parts)-1]
		m[d] = struct{}{}
	}
}

func loadFileToSlice(path string, s *[]string) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		*s = append(*s, line)
	}
}

func IsBlocked(q string) bool {
	q = strings.TrimSuffix(q, ".")
	r := current.Load().(*Rules)
	if r == nil {
		return false
	}
	if _, ok := r.Block[q]; ok {
		return true
	}
	parts := strings.Split(q, ".")
	for i := 0; i < len(parts)-1; i++ {
		sub := strings.Join(parts[i:], ".")
		if _, ok := r.Block[sub]; ok {
			return true
		}
	}
	return false
}

func IsChinaSuffix(q string) bool {
	q = strings.TrimSuffix(q, ".")
	r := current.Load().(*Rules)
	if r == nil {
		return false
	}
	for _, s := range r.Split {
		if strings.HasSuffix(q, s) {
			return true
		}
	}
	return false
}

// AddBlock adds a domain to blocklist and persists to file.
func AddBlock(domain string) error {
	path := filepath.Join(rulesDir, "blocklist.txt")
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	if _, err := f.WriteString(domain + "\n"); err != nil {
		return err
	}
	LoadAll(rulesDir)
	return nil
}

// DeleteBlock removes a domain from blocklist and rewrites file.
func DeleteBlock(domain string) error {
	path := filepath.Join(rulesDir, "blocklist.txt")
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	lines := []string{}
	for _, l := range strings.Split(string(data), "\n") {
		t := strings.TrimSpace(l)
		if t == "" || strings.HasPrefix(t, "#") {
			continue
		}
		if t == domain || strings.HasSuffix(t, " "+domain) {
			continue
		}
		lines = append(lines, l)
	}
	return os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), 0644)
}

// AddSplit adds suffix and persists
func AddSplit(suffix string) error {
	path := filepath.Join(rulesDir, "china_suffixes.txt")
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	if _, err := f.WriteString(suffix + "\n"); err != nil {
		return err
	}
	LoadAll(rulesDir)
	return nil
}

// DeleteSplit removes suffix
func DeleteSplit(suffix string) error {
	path := filepath.Join(rulesDir, "china_suffixes.txt")
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	lines := []string{}
	for _, l := range strings.Split(string(data), "\n") {
		t := strings.TrimSpace(l)
		if t == "" || strings.HasPrefix(t, "#") {
			continue
		}
		if t == suffix {
			continue
		}
		lines = append(lines, l)
	}
	return os.WriteFile(path, []byte(strings.Join(lines, "\n")+"\n"), 0644)
}

// ImportFromURL imports a txt list from URL and appends to file (block or split)
func ImportFromURL(url string, target string) (int, error) {
	resp, err := http.Get(url)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return 0, http.ErrBodyNotAllowed
	}
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}
	lines := strings.Split(string(b), "\\n")
	count := 0
	path := filepath.Join(rulesDir, target)
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return 0, err
	}
	defer f.Close()
	for _, l := range lines {
		t := strings.TrimSpace(l)
		if t == "" || strings.HasPrefix(t, "#") {
			continue
		}
		if _, err := f.WriteString(t + \"\\n\"); err == nil {
			count++
		}
	}
	LoadAll(rulesDir)
	return count, nil
}

func WatchAndReload(dir string) {
	w, err := fsnotify.NewWatcher()
	if err != nil {
		log.Println(\"watcher error:\", err)
		return
	}
	defer w.Close()
	_ = w.Add(dir)
	for {
		select {
		case ev := <-w.Events:
			if ev.Op&(fsnotify.Write|fsnotify.Create|fsnotify.Remove) != 0 {
				log.Println(\"rules change detected, reloading...\")
				LoadAll(dir)
			}
		case err := <-w.Errors:
			if err != nil {
				log.Println(\"watcher error:\", err)
			}
		}
		time.Sleep(500 * time.Millisecond)
	}
}

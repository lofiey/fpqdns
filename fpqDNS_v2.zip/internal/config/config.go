
package config

import (
	"io/ioutil"
	"gopkg.in/yaml.v3"
)

type Upstream struct {
	Name string `yaml:"name"`
	Type string `yaml:"type"`
	Addr string `yaml:"addr"`
}

type Config struct {
	Listen struct {
		DoH   string `yaml:"doh"`
		Admin string `yaml:"admin"`
	} `yaml:"listen"`
	Cache struct {
		DefaultTTL int `yaml:"default_ttl"`
	} `yaml:"cache"`
	Upstreams []Upstream `yaml:"upstreams"`
	Rules struct {
		BlockFile string `yaml:"block_file"`
		SplitFile string `yaml:"split_file"`
	} `yaml:"rules"`
	Admin struct {
		JWTSecret string `yaml:"jwt_secret"`
	} `yaml:"admin"`
}

var Cfg Config

func LoadConfig(path string) error {
	b, err := ioutil.ReadFile(path)
	if err != nil {
		return err
	}
	return yaml.Unmarshal(b, &Cfg)
}

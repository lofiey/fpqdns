
package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"fpqdns/internal/cache"
	"fpqdns/internal/config"
	"fpqdns/internal/listener"
	"fpqdns/internal/resolver"
	"fpqdns/internal/rules"
	"fpqdns/internal/api"
)

func main() {
	if err := config.LoadConfig("configs/config.yaml"); err != nil {
		log.Fatalf("load config: %v", err)
	}
	cache.InitCache()
	rules.LoadAll("rules")
	go rules.WatchAndReload("rules")
	resolver.InitUpstreams()
	// start admin API (with JWT protection)
	go api.StartAdmin()
	// start DoH and static admin on same port
	if err := listener.Start(); err != nil {
		log.Fatalf("listener: %v", err)
	}
	// wait signal
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Println("shutting down")
}

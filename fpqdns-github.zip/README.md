# FPQ DNS

FPQ DNS 是一个类似 AdGuard Home 的 DNS 系统，支持：

- DoH/UDP DNS 服务
- 缓存管理
- 国内/国外域名分流
- 拦截域名管理（Blocklist）
- 上游 DNS 管理
- 前端管理面板（Vue3）

## 快速运行

### 1. 后端

```bash
cd fpqdns
go mod tidy
go build -o fpqdns main.go
./fpqdns
```

### 2. 前端管理

```bash
cd web
npm install
npm run dev
```

访问管理面板: http://127.0.0.1:8080

默认账号：
用户名：admin
密码：changeme

## 数据文件位置

- fpqdns/data/config.json → 配置
- fpqdns/data/blocklist.txt → 拦截域名
- fpqdns/data/split_rules.txt → 分流规则
- fpqdns/data/upstreams.json → 上游 DNS
- fpqdns/data/users.json → 用户
